from __future__ import annotations

import html
import json
import re
from dataclasses import dataclass
from typing import Any, Awaitable, Callable

from tools import ToolRegistry

ChatFunction = Callable[[str, str], Awaitable[str]]

@dataclass
class AgentResult:
    content: str
    steps: list[dict[str, Any]]

class AgentRunner:
    def __init__(self, tools: ToolRegistry, chat: ChatFunction, max_steps: int = 8, max_parse_failures: int = 3):
        self.tools = tools
        self.chat = chat
        self.max_steps = max(1, min(int(max_steps), 100))
        self.max_parse_failures = max(2, min(int(max_parse_failures), 5))

    def _system_prompt(self) -> str:
        return """你是本地任务 Agent，可以通过工具处理当前工作目录中的文件。
每次只返回一个 JSON 对象。不得使用 Markdown 代码块，不得在 JSON 前后添加解释。
格式只有两种：
{"type":"tool","tool":"工具名","arguments":{},"reason":"原因"}
{"type":"final","content":"最终答复"}
规则：先检查再修改；路径相对于当前工作目录；工具失败后调整方案；完成后必须立即返回 final。
创建长文件时必须分段：先 write_text，后续 append_text；每次 content 不超过 1800 字符。文件写完后用 read_text 验证。
可用工具：
""" + json.dumps(self.tools.descriptions(), ensure_ascii=False)

    @staticmethod
    def _objects(text: str):
        text = html.unescape((text or '').strip()).replace('\ufeff', '')
        text = re.sub(r'^```(?:json)?\s*|\s*```$', '', text, flags=re.I | re.S).strip()
        variants = [text]
        # Copilot may return a JSON string that contains an escaped JSON object.
        try:
            decoded = json.loads(text)
            if isinstance(decoded, str):
                variants.append(decoded)
            elif isinstance(decoded, dict):
                yield decoded
        except Exception:
            pass
        decoder = json.JSONDecoder()
        for value in variants:
            for start, ch in enumerate(value):
                if ch != '{':
                    continue
                try:
                    obj, _ = decoder.raw_decode(value[start:])
                    if isinstance(obj, dict):
                        yield obj
                except Exception:
                    continue

    @classmethod
    def _parse(cls, text: str) -> dict[str, Any]:
        candidates = list(cls._objects(text))
        # Prefer final if the page contains stale/intermediate JSON plus the final answer.
        for wanted in ('final', 'tool'):
            for obj in reversed(candidates):
                kind = str(obj.get('type', '')).strip().lower()
                if kind == wanted:
                    obj['type'] = kind
                    if kind == 'final':
                        content = obj.get('content', obj.get('message', obj.get('answer', '')))
                        if isinstance(content, (dict, list)):
                            content = json.dumps(content, ensure_ascii=False)
                        obj['content'] = str(content or '').strip()
                    else:
                        obj['tool'] = str(obj.get('tool', '')).strip()
                        if not isinstance(obj.get('arguments'), dict):
                            obj['arguments'] = {}
                    return obj
        # Last-resort final tolerance for a visibly complete final payload.
        m = re.search(r'["\']type["\']\s*:\s*["\']final["\']', html.unescape(text or ''), re.I)
        if m:
            m2 = re.search(r'["\']content["\']\s*:\s*["\'](.*)["\']\s*\}?\s*$', html.unescape(text or ''), re.I | re.S)
            if m2:
                content = m2.group(1).replace('\\n', '\n').replace('\\"', '"')
                return {'type': 'final', 'content': content}
        raise ValueError('Copilot 未返回完整、可解析的 Agent JSON 动作')

    async def run(self, user_request: str, model: str) -> AgentResult:
        history: list[dict[str, Any]] = []
        steps: list[dict[str, Any]] = []
        parse_failures = 0
        for index in range(1, self.max_steps + 1):
            prompt = self._system_prompt() + '\n\n用户任务：\n' + user_request
            if history:
                prompt += '\n\n已执行记录：\n' + json.dumps(history, ensure_ascii=False)
            prompt += f'\n\n当前是第 {index}/{self.max_steps} 步。只返回下一个 JSON 动作。'
            raw = await self.chat(prompt, model)
            try:
                action = self._parse(raw)
                parse_failures = 0
            except Exception as exc:
                parse_failures += 1
                step = {'step': index, 'status': 'invalid_action', 'error': str(exc), 'raw_tail': (raw or '')[-2000:]}
                steps.append(step)
                history.append(step)
                if parse_failures >= self.max_parse_failures:
                    return AgentResult('Copilot 连续返回无法解析的动作，Agent 已安全停止，未继续重复发送。', steps)
                continue
            if action['type'] == 'final':
                return AgentResult(action.get('content') or '任务已完成。', steps)
            tool, arguments = action.get('tool', ''), action.get('arguments') or {}
            step = {'step': index, 'tool': tool, 'arguments': arguments, 'reason': action.get('reason', '')}
            try:
                result = await self.tools.execute(tool, arguments)
                step.update({'status': 'ok', 'result': result})
            except Exception as exc:
                step.update({'status': 'error', 'error': str(exc)})
            steps.append(step); history.append(step)
        return AgentResult(f'Agent 已达到最大步骤数 {self.max_steps}，任务未正常结束。', steps)
