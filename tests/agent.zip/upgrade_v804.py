from __future__ import annotations
import json, re, shutil, sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
required = [BASE/'app.py', BASE/'agent.py', BASE/'tools.py', BASE/'config.json', BASE/'webui'/'index.html']
missing = [str(x.name) for x in required if not x.exists()]
if missing:
    raise SystemExit('请把本文件放到 CopilotBridge 根目录后运行。缺少: ' + ', '.join(missing))
for f in required:
    shutil.copy2(f, f.with_suffix(f.suffix + '.v803.bak'))

# 1) Replace agent loop with robust JSON/final handling.
agent = r'''from __future__ import annotations

import html
import json
import re
from dataclasses import dataclass
from typing import Any, Awaitable, Callable

from tools import ToolRegistry

ChatFunction = Callable[[str, str], Awaitable[str]]

@dataclass
class AgentResult:
    content: str
    steps: list[dict[str, Any]]

class AgentRunner:
    def __init__(self, tools: ToolRegistry, chat: ChatFunction, max_steps: int = 8, max_parse_failures: int = 2):
        self.tools = tools
        self.chat = chat
        self.max_steps = max(1, min(int(max_steps), 30))
        self.max_parse_failures = max(1, min(int(max_parse_failures), 3))

    def _system_prompt(self) -> str:
        return """你是本地任务 Agent，可以通过工具处理当前工作目录中的文件。
每次只返回一个 JSON 对象。不得使用 Markdown 代码块，不得在 JSON 前后添加解释。
格式只有两种：
{"type":"tool","tool":"工具名","arguments":{},"reason":"原因"}
{"type":"final","content":"最终答复"}
规则：先检查再修改；路径相对于当前工作目录；工具失败后调整方案；完成后必须立即返回 final。
可用工具：
""" + json.dumps(self.tools.descriptions(), ensure_ascii=False)

    @staticmethod
    def _objects(text: str):
        text = html.unescape((text or '').strip()).replace('\ufeff', '')
        text = re.sub(r'^```(?:json)?\s*|\s*```$', '', text, flags=re.I | re.S).strip()
        variants = [text]
        # Copilot may return a JSON string that contains an escaped JSON object.
        try:
            decoded = json.loads(text)
            if isinstance(decoded, str):
                variants.append(decoded)
            elif isinstance(decoded, dict):
                yield decoded
        except Exception:
            pass
        decoder = json.JSONDecoder()
        for value in variants:
            for start, ch in enumerate(value):
                if ch != '{':
                    continue
                try:
                    obj, _ = decoder.raw_decode(value[start:])
                    if isinstance(obj, dict):
                        yield obj
                except Exception:
                    continue

    @classmethod
    def _parse(cls, text: str) -> dict[str, Any]:
        candidates = list(cls._objects(text))
        # Prefer final if the page contains stale/intermediate JSON plus the final answer.
        for wanted in ('final', 'tool'):
            for obj in reversed(candidates):
                kind = str(obj.get('type', '')).strip().lower()
                if kind == wanted:
                    obj['type'] = kind
                    if kind == 'final':
                        content = obj.get('content', obj.get('message', obj.get('answer', '')))
                        if isinstance(content, (dict, list)):
                            content = json.dumps(content, ensure_ascii=False)
                        obj['content'] = str(content or '').strip()
                    else:
                        obj['tool'] = str(obj.get('tool', '')).strip()
                        if not isinstance(obj.get('arguments'), dict):
                            obj['arguments'] = {}
                    return obj
        # Last-resort final tolerance for a visibly complete final payload.
        m = re.search(r'["\']type["\']\s*:\s*["\']final["\']', html.unescape(text or ''), re.I)
        if m:
            m2 = re.search(r'["\']content["\']\s*:\s*["\'](.*)["\']\s*\}?\s*$', html.unescape(text or ''), re.I | re.S)
            if m2:
                content = m2.group(1).replace('\\n', '\n').replace('\\"', '"')
                return {'type': 'final', 'content': content}
        raise ValueError('Copilot 未返回完整、可解析的 Agent JSON 动作')

    async def run(self, user_request: str, model: str) -> AgentResult:
        history: list[dict[str, Any]] = []
        steps: list[dict[str, Any]] = []
        parse_failures = 0
        for index in range(1, self.max_steps + 1):
            prompt = self._system_prompt() + '\n\n用户任务：\n' + user_request
            if history:
                prompt += '\n\n已执行记录：\n' + json.dumps(history, ensure_ascii=False)
            prompt += f'\n\n当前是第 {index}/{self.max_steps} 步。只返回下一个 JSON 动作。'
            raw = await self.chat(prompt, model)
            try:
                action = self._parse(raw)
                parse_failures = 0
            except Exception as exc:
                parse_failures += 1
                step = {'step': index, 'status': 'invalid_action', 'error': str(exc), 'raw_tail': (raw or '')[-2000:]}
                steps.append(step)
                history.append(step)
                if parse_failures >= self.max_parse_failures:
                    return AgentResult('Copilot 连续返回无法解析的动作，Agent 已安全停止，未继续重复发送。', steps)
                continue
            if action['type'] == 'final':
                return AgentResult(action.get('content') or '任务已完成。', steps)
            tool, arguments = action.get('tool', ''), action.get('arguments') or {}
            step = {'step': index, 'tool': tool, 'arguments': arguments, 'reason': action.get('reason', '')}
            try:
                result = await self.tools.execute(tool, arguments)
                step.update({'status': 'ok', 'result': result})
            except Exception as exc:
                step.update({'status': 'error', 'error': str(exc)})
            steps.append(step); history.append(step)
        return AgentResult(f'Agent 已达到最大步骤数 {self.max_steps}，任务未正常结束。', steps)
'''
(BASE/'agent.py').write_text(agent, encoding='utf-8')

# 2) Add switchable root to tools.py.
p = BASE/'tools.py'; s=p.read_text(encoding='utf-8')
if 'def set_root(' not in s:
    marker='    def descriptions(self) -> list[dict[str, Any]]:\n'
    method='''    def set_root(self, root: str | Path, create: bool = False) -> str:
        target = Path(root).expanduser().resolve()
        if create:
            target.mkdir(parents=True, exist_ok=True)
        if not target.exists() or not target.is_dir():
            raise ToolError(f"工作目录不存在或不是目录: {target}")
        self.root = target
        return str(self.root)

'''
    if marker not in s: raise SystemExit('tools.py 结构不匹配')
    s=s.replace(marker, method+marker, 1)
p.write_text(s, encoding='utf-8')

# 3) Patch app models/session/workspace and stable answer logic.
p=BASE/'app.py'; s=p.read_text(encoding='utf-8')
if 'workspace: str | None' not in s:
    s=s.replace('    reuse_session: bool = True\n', '    reuse_session: bool = True\n    workspace: str | None = None\n')
# session save signature + workspace
s=s.replace('def save(self, session_id: str, url: str, model: str):', 'def save(self, session_id: str, url: str, model: str, workspace: str | None = None):')
s=s.replace('"created": created, "last_used": now,\n        }', '"created": created, "last_used": now,\n            "workspace": workspace or self.sessions.get(session_id, {}).get("workspace"),\n        }')
# Root selection inside run_agent, before lock.
needle='    session_id = req.session_id or ("web-" + uuid.uuid4().hex[:12])\n\n    async with lock:\n'
replacement='''    session_id = req.session_id or ("web-" + uuid.uuid4().hex[:12])
    requested_workspace = req.workspace.strip() if req.workspace else None

    async with lock:
'''
if needle in s: s=s.replace(needle,replacement,1)
# After existing get, select workspace.
needle='        existing = AGENT_SESSIONS.get(session_id) if req.reuse_session else None\n'
replacement='''        existing = AGENT_SESSIONS.get(session_id) if req.reuse_session else None
        workspace = requested_workspace or (existing or {}).get("workspace") or str(AGENT_WORKSPACE)
        AGENT_TOOLS.set_root(workspace, create=False)
'''
if needle in s: s=s.replace(needle,replacement,1)
# Save calls all include current root.
s=s.replace('AGENT_SESSIONS.save(session_id, page.url, model_id)', 'AGENT_SESSIONS.save(session_id, page.url, model_id, str(AGENT_TOOLS.root))')
s=s.replace('AGENT_SESSIONS.save(session_id, page.url, req.model)', 'AGENT_SESSIONS.save(session_id, page.url, req.model, str(AGENT_TOOLS.root))')
# Response workspace.
s=s.replace('"session_id": session_id,\n        })', '"session_id": session_id,\n            "workspace": str(AGENT_TOOLS.root),\n        })')
s=s.replace('"session_id": session_id,\n        }', '"session_id": session_id,\n            "workspace": str(AGENT_TOOLS.root),\n        }')
# Replace wait_agent_answer and agent_chat_once block.
start=s.find('async def wait_agent_answer()')
end=s.find('\nasync def run_agent(', start)
if start < 0 or end < 0: raise SystemExit('app.py 中找不到回答等待函数')
new_wait=r'''def _has_complete_agent_action(text: str) -> bool:
    try:
        from agent import AgentRunner
        return AgentRunner._parse(text).get("type") in {"tool", "final"}
    except Exception:
        return False

async def wait_agent_answer(previous: str = "") -> str:
    deadline = time.monotonic() + TIMEOUT
    current = ""
    last_change = time.monotonic()
    seen_new = False
    while time.monotonic() < deadline:
        await asyncio.sleep(POLL)
        value = (await current_answer()).strip()
        if not value or value == previous:
            continue
        seen_new = True
        if value != current:
            current = value
            last_change = time.monotonic()
        complete = _has_complete_agent_action(current)
        stable_for = time.monotonic() - last_change
        signal = await completion_signal()
        # A complete action plus the page completion signal is enough. Otherwise
        # require a longer stable window to avoid capturing partial JSON.
        if signal and complete and stable_for >= max(0.6, POLL * 2):
            await diagnostics("agent_answer_ready")
            return current
        if signal and stable_for >= max(STABLE, 2.0):
            await diagnostics("agent_answer_stable")
            return current
    final = (await current_answer()).strip()
    if seen_new and final and final != previous:
        return final
    await diagnostics("agent_answer_timeout")
    raise TimeoutError("等待新的 Agent JSON 回答超时，请查看 last_page.txt")

async def agent_chat_once(prompt: str, model_id: str, make_new: bool = False) -> str:
    previous = "" if make_new else (await current_answer()).strip()
    await send(prompt, make_new, model_id)
    return await wait_agent_answer(previous)
'''
s=s[:start]+new_wait+s[end:]
# Add workspace endpoints before tools route.
route='@app.get("/v1/agent/tools")\n'
if '/v1/agent/workspace' not in s:
    extra='''@app.get("/v1/agent/workspace")
async def get_agent_workspace():
    return {"workspace": str(AGENT_TOOLS.root)}

@app.post("/v1/agent/workspace")
async def set_agent_workspace(payload: dict):
    path = str(payload.get("path", "")).strip()
    if not path:
        raise HTTPException(400, "path 不能为空")
    try:
        return {"workspace": AGENT_TOOLS.set_root(path, bool(payload.get("create", False)))}
    except Exception as exc:
        raise HTTPException(400, str(exc)) from exc

'''
    s=s.replace(route, extra+route, 1)
s=s.replace('version="8.0.3"','version="8.0.4"').replace('"version": "8.0.3"','"version": "8.0.4"')
p.write_text(s, encoding='utf-8')

# 4) Web UI: add workspace field and send it with each request.
p=BASE/'webui'/'index.html'; s=p.read_text(encoding='utf-8')
if 'id="workspace"' not in s:
    s=s.replace('<section class="composer">', '<section class="composer"><div style="display:flex;gap:8px;margin-bottom:8px"><input class="field" id="workspace" style="flex:1" placeholder="工作目录，例如 C:\\\\Work\\\\Agent"><button class="field" id="setWorkspace">切换目录</button></div>')
    s=s.replace('session_id:sessionId,reuse_session:$(\'reuse\').checked', 'session_id:sessionId,reuse_session:$(\'reuse\').checked,workspace:$(\'workspace\').value.trim()||null')
    hook="loadModels().then(loadSessions);setInterval(loadSessions,15000);"
    code="""$('setWorkspace').onclick=async()=>{let path=$('workspace').value.trim();if(!path)return;let r=await fetch('/v1/agent/workspace',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path})});let j=await r.json();if(!r.ok){alert(j.detail||'切换失败');return}$('workspace').value=j.workspace;localStorage.agentWorkspace=j.workspace;$('status').textContent='工作目录：'+j.workspace};$('workspace').value=localStorage.agentWorkspace||'';"""
    s=s.replace(hook,code+hook)
p.write_text(s, encoding='utf-8')

# 5) Config and README.
p=BASE/'config.json'; cfg=json.loads(p.read_text(encoding='utf-8')); cfg.setdefault('agent',{})['max_parse_failures']=2
p.write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding='utf-8')
print('升级完成：v8.0.4。备份文件扩展名为 .v803.bak')
