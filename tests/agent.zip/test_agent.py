import json
import urllib.request

payload = {
    "model": "copilot-auto",
    "messages": [{"role": "user", "content": "列出工作区文件，并创建 hello.txt，内容为 Agent test success。"}],
    "stream": False,
    "max_steps": 6
}
req = urllib.request.Request(
    "http://127.0.0.1:8765/v1/agent/completions",
    data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
    headers={"Content-Type": "application/json"},
    method="POST",
)
with urllib.request.urlopen(req, timeout=300) as response:
    print(response.read().decode("utf-8"))
