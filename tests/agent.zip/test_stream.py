import json
import urllib.request

payload = {
    "model": "copilot-auto",
    "messages": [{"role": "user", "content": "请用三点说明 DHCP Snooping 的作用。"}],
    "stream": True
}
req = urllib.request.Request(
    "http://127.0.0.1:8765/v1/chat/completions",
    data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
    headers={"Content-Type": "application/json"},
    method="POST",
)
with urllib.request.urlopen(req, timeout=300) as response:
    for raw in response:
        line = raw.decode("utf-8").strip()
        if not line.startswith("data: "):
            continue
        data = line[6:]
        if data == "[DONE]":
            print()
            break
        obj = json.loads(data)
        if "error" in obj:
            print("\nERROR:", obj["error"])
            break
        print(obj["choices"][0]["delta"].get("content", ""), end="", flush=True)
