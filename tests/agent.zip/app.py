import asyncio, json, re, time, uuid
from os.path import commonprefix
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path
from typing import Literal
from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse, FileResponse
from playwright.async_api import async_playwright
from pydantic import BaseModel, Field
from agent import AgentRunner
from tools import ToolRegistry

BASE = Path(__file__).resolve().parent
CFG = json.loads((BASE / "config.json").read_text(encoding="utf-8"))
PROFILE = BASE / "EdgeProfile"
URL = CFG["copilot_url"]
TIMEOUT = float(CFG.get("reply_timeout_seconds", 180))
STABLE = float(CFG.get("stable_seconds", 3))
POLL = float(CFG.get("poll_interval_seconds", .35))
DIAG = bool(CFG.get("diagnostics", True))

# API model ID -> possible labels shown by the Copilot web interface.
# Keep the first label as the preferred name. Add labels here if your tenant
# displays different wording.
MODELS = {
    "copilot-auto": {
        "ui_names": ["Auto", "自动"],
        "description": "由 Microsoft 365 Copilot 自动选择回答模式",
    },
    "copilot-quick-response": {
        "ui_names": ["Quick response", "Quick", "快速响应", "快速"],
        "description": "优先快速响应",
    },
    "copilot-think-deeper": {
        "ui_names": ["Think deeper", "Think Deeper", "深入思考"],
        "description": "使用更深入的推理模式",
    },
    "copilot-gpt": {
        "ui_names": ["GPT"],
        "description": "使用 Copilot 菜单中的 GPT 模型",
    },
    "copilot-gpt-5-6": {
        "ui_names": ["GPT-5.6", "GPT 5.6", "GPT5.6"],
        "description": "使用 Copilot 菜单中的 GPT-5.6 模型",
    },
    "copilot-sol": {
        "ui_names": ["Sol", "SOL"],
        "description": "使用 Copilot 菜单中的 Sol 模型",
    },
    "copilot-think": {
        "ui_names": ["Think", "思考"],
        "description": "使用 Copilot 菜单中的 Think 模型",
    },
}

# Optional config.json extension. This lets you add or override models without
# editing app.py. Example:
# "models": {"copilot-custom": {"ui_names": ["Custom"], "description": "Custom model"}}
for custom_id, custom_item in CFG.get("models", {}).items():
    if isinstance(custom_item, dict) and custom_item.get("ui_names"):
        MODELS[custom_id] = {
            "ui_names": list(custom_item["ui_names"]),
            "description": custom_item.get("description", custom_id),
        }

# Backward compatibility with the model name used by v7.0.0.
MODEL_ALIASES = {
    "copilot-chat-basic-web": "copilot-auto",
}
DEFAULT_MODEL = CFG.get("default_model", "copilot-auto")

pw = ctx = page = None
lock = asyncio.Lock()


class Message(BaseModel):
    role: Literal["system", "user", "assistant"]
    content: str


class Request(BaseModel):
    model: str = DEFAULT_MODEL
    messages: list[Message] = Field(min_length=1)
    stream: bool = True
    new_conversation: bool = True

class AgentRequest(BaseModel):
    model: str = DEFAULT_MODEL
    messages: list[Message] = Field(min_length=1)
    stream: bool = False
    max_steps: int | None = Field(default=None, ge=1, le=100)
    session_id: str | None = Field(default=None, min_length=3, max_length=100)
    reuse_session: bool = True
    workspace: str | None = None


def log(s):
    print(f"[{datetime.now():%H:%M:%S}] {s}", flush=True)


def normalize_model(model_id):
    normalized = MODEL_ALIASES.get(model_id, model_id)
    if normalized not in MODELS:
        raise HTTPException(
            400,
            detail={
                "message": f"不支持的模型: {model_id}",
                "type": "invalid_request_error",
                "available_models": list(MODELS),
            },
        )
    return normalized


async def diagnostics(tag):
    if not DIAG or page is None:
        return
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    try:
        await page.screenshot(path=str(BASE / "last_state.png"), full_page=True)
        await page.screenshot(path=str(BASE / f"{tag}_{stamp}.png"), full_page=True)
    except Exception:
        pass
    try:
        text = await page.locator("body").inner_text()
        (BASE / "last_page.txt").write_text(text, encoding="utf-8")
        (BASE / "last_page.html").write_text(await page.content(), encoding="utf-8")
    except Exception:
        pass


async def visible(selectors):
    for selector in selectors:
        loc = page.locator(selector)
        for i in range(await loc.count() - 1, -1, -1):
            try:
                if await loc.nth(i).is_visible():
                    return loc.nth(i)
            except Exception:
                pass
    return None


async def visible_locator(locators):
    for loc in locators:
        try:
            count = await loc.count()
            for i in range(count - 1, -1, -1):
                item = loc.nth(i)
                if await item.is_visible():
                    return item
        except Exception:
            pass
    return None


async def dismiss():
    b = await visible([
        'button:has-text("Accept")',
        'button:has-text("接受")',
        'button:has-text("Got it")',
        'button:has-text("知道了")',
        'button:has-text("Not now")',
        'button:has-text("暂不")',
    ])
    if b:
        try:
            await b.click(timeout=1000)
        except Exception:
            pass


async def new_chat():
    b = await visible([
        'button[aria-label*="New chat" i]',
        'a[aria-label*="New chat" i]',
        'button:has-text("New chat")',
        'button:has-text("新建聊天")',
    ])
    if b:
        await b.click()
        await asyncio.sleep(1)
    else:
        await page.goto(URL, wait_until="domcontentloaded", timeout=120000)
        await asyncio.sleep(2)


async def model_button():
    all_names = [name for item in MODELS.values() for name in item["ui_names"]]
    exact = re.compile(
        r"^(?:" + "|".join(re.escape(name) for name in all_names) + r")$",
        re.I,
    )
    button = await visible_locator([
        page.get_by_role("button", name=exact),
        page.locator('button[aria-haspopup="menu"]').filter(has_text=exact),
        page.locator('button[aria-haspopup="listbox"]').filter(has_text=exact),
        page.locator('[role="button"][aria-haspopup="menu"]').filter(has_text=exact),
        page.locator('[role="button"][aria-haspopup="listbox"]').filter(has_text=exact),
    ])
    return button


async def select_model(model_id):
    normalized = normalize_model(model_id)
    target_names = MODELS[normalized]["ui_names"]
    button = await model_button()
    if not button:
        await diagnostics("no_model_button")
        raise RuntimeError("找不到 Copilot 左上角的模型选择按钮")

    current = (await button.inner_text()).strip()
    if any(current.casefold() == name.casefold() for name in target_names):
        log(f"模型已是 {normalized} ({current})")
        return normalized

    await button.click(timeout=3000)
    await asyncio.sleep(.45)

    target = re.compile(
        r"^(?:" + "|".join(re.escape(name) for name in target_names) + r")$",
        re.I,
    )
    option = await visible_locator([
        page.get_by_role("option", name=target),
        page.get_by_role("menuitem", name=target),
        page.get_by_role("menuitemradio", name=target),
        page.get_by_text(target, exact=True),
        page.get_by_role("option", name=target, exact=False),
        page.get_by_role("menuitem", name=target, exact=False),
        page.get_by_role("menuitemradio", name=target, exact=False),
        page.get_by_text(target, exact=False),
    ])
    if not option:
        try:
            await page.keyboard.press("Escape")
        except Exception:
            pass
        await diagnostics("model_option_missing")
        raise RuntimeError(
            f"模型菜单中找不到 {target_names[0]}。"
            "请查看 last_page.txt，并按页面实际文字修改 MODELS。"
        )

    await option.click(timeout=3000)
    await asyncio.sleep(.8)
    log(f"模型已切换为 {normalized}")
    return normalized


async def input_box():
    x = await visible([
        'textarea[placeholder]',
        'textarea',
        '[contenteditable="true"][role="textbox"]',
        '[contenteditable="true"]',
        '[role="textbox"]',
    ])
    if not x:
        await diagnostics("no_input")
        raise RuntimeError("找不到输入框，请重新运行 login.py")
    return x


async def body_text():
    try:
        return (await page.locator("body").inner_text()).replace("\r\n", "\n")
    except Exception:
        return ""


def extract_latest_answer(text):
    # Select only the final Copilot said block to avoid sidebar/history text.
    marker = "Copilot said:"
    if marker not in text:
        return ""
    answer = text.rsplit(marker, 1)[1]
    end_markers = [
        "\nSources\n",
        "\nMessage Copilot\n",
        "\nAI-generated content may be incorrect",
    ]
    positions = [answer.find(m) for m in end_markers if answer.find(m) >= 0]
    if positions:
        answer = answer[:min(positions)]
    ignored = {
        "Copy", "Like", "Dislike", "More", "Share", "Regenerate",
        "复制", "来源", "赞", "踩", "更多", "分享", "重新生成",
    }
    lines = []
    for line in answer.splitlines():
        line = line.rstrip()
        if line.strip() in ignored:
            continue
        lines.append(line)
    return "\n".join(lines).strip()


async def current_answer():
    return extract_latest_answer(await body_text())


async def generating():
    return bool(await visible([
        'button[aria-label*="Stop" i]',
        'button:has-text("Stop generating")',
        'button:has-text("停止生成")',
    ]))


def delta(old, new):
    if not old:
        return new
    if new.startswith(old):
        return new[len(old):]
    stripped = old.rstrip()
    if new.startswith(stripped):
        return new[len(stripped):]
    return ""


async def count_user_markers():
    text = await body_text()
    return text.count("You said:")


async def box_value(box):
    try:
        tag = await box.evaluate("el => el.tagName.toLowerCase()")
        if tag in {"textarea", "input"}:
            return (await box.input_value()).strip()
        return (await box.inner_text()).strip()
    except Exception:
        return ""


async def sent_successfully(box, before_count, prompt):
    for _ in range(12):
        await asyncio.sleep(.25)
        now_count = await count_user_markers()
        value = await box_value(box)
        if now_count > before_count:
            return True
        if not value:
            page_now = await body_text()
            if prompt in page_now:
                return True
    return False


async def click_send_button():
    button = await visible([
        'button[aria-label="Send"]',
        'button[aria-label*="Send" i]',
        'button[title*="Send" i]',
        'button[aria-label*="发送"]',
        'button[title*="发送"]',
        'button[data-testid*="send" i]',
    ])
    if button:
        try:
            await button.click(timeout=2000)
            return True
        except Exception:
            pass
    return False


async def send(prompt, make_new, model_id):
    await dismiss()
    if make_new:
        await new_chat()
    # Select after New chat because opening a new conversation can reset Auto.
    selected_model = await select_model(model_id)

    box = await input_box()
    await box.click()
    try:
        await box.fill(prompt)
    except Exception:
        await box.press("Control+A")
        await box.press_sequentially(prompt)
    before_count = await count_user_markers()

    await box.press("Enter")
    if await sent_successfully(box, before_count, prompt):
        await diagnostics("sent")
        log("问题已发送")
        return selected_model

    await box.click()
    if await click_send_button() and await sent_successfully(box, before_count, prompt):
        await diagnostics("sent_button")
        log("问题已通过发送按钮提交")
        return selected_model

    await box.click()
    await box.press("Control+Enter")
    if await sent_successfully(box, before_count, prompt):
        await diagnostics("sent_ctrl_enter")
        log("问题已通过 Ctrl+Enter 提交")
        return selected_model

    await diagnostics("send_failed")
    raise RuntimeError("问题停留在输入框，Enter、发送按钮和 Ctrl+Enter 均未触发发送")


async def completion_signal():
    text = await body_text()
    answer = text.rsplit("Copilot said:", 1)[1] if "Copilot said:" in text else ""
    has_sources = "\nSources\n" in answer or answer.rstrip().endswith("Sources")
    stop_button = await visible([
        'button[aria-label*="Stop" i]',
        'button:has-text("Stop generating")',
        'button:has-text("停止生成")',
    ])
    return has_sources or stop_button is None


async def updates():
    deadline = time.monotonic() + TIMEOUT
    previous = ""
    emitted = 0
    unchanged_since = None
    started = False
    while time.monotonic() < deadline:
        await asyncio.sleep(POLL)
        current = await current_answer()
        if not current:
            continue
        if current == previous:
            unchanged_since = unchanged_since or time.monotonic()
        else:
            unchanged_since = None
        stable_prefix = commonprefix([previous, current]) if previous else ""
        if len(stable_prefix) > emitted:
            part = stable_prefix[emitted:]
            emitted = len(stable_prefix)
            if part:
                if not started:
                    started = True
                    log("已识别 Copilot said 区域，开始流式返回")
                yield part
        previous = current
        settled = unchanged_since is not None and time.monotonic() - unchanged_since >= STABLE
        if current and settled and await completion_signal():
            if len(current) > emitted:
                yield current[emitted:]
                emitted = len(current)
            await diagnostics("success")
            log(f"回答完成，共 {len(current)} 字符")
            return
    final = await current_answer()
    if final and await completion_signal():
        if len(final) > emitted:
            yield final[emitted:]
        await diagnostics("success_late")
        log(f"回答延迟完成，共 {len(final)} 字符")
        return
    await diagnostics("timeout")
    raise TimeoutError("等待回答超时，请查看 last_page.txt")


def sse(data):
    if isinstance(data, str):
        return f"data: {data}\n\n"
    return "data: " + json.dumps(data, ensure_ascii=False) + "\n\n"


async def stream_response(req, prompt):
    rid = "chatcmpl-" + uuid.uuid4().hex
    created = int(time.time())
    async with lock:
        try:
            selected_model = await send(prompt, req.new_conversation, req.model)
            yield sse({
                "id": rid,
                "object": "chat.completion.chunk",
                "created": created,
                "model": selected_model,
                "choices": [{"index": 0, "delta": {"role": "assistant"}, "finish_reason": None}],
            })
            async for part in updates():
                yield sse({
                    "id": rid,
                    "object": "chat.completion.chunk",
                    "created": created,
                    "model": selected_model,
                    "choices": [{"index": 0, "delta": {"content": part}, "finish_reason": None}],
                })
            yield sse({
                "id": rid,
                "object": "chat.completion.chunk",
                "created": created,
                "model": selected_model,
                "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
            })
            yield sse("[DONE]")
        except asyncio.CancelledError:
            log("客户端已断开")
            raise
        except Exception as e:
            await diagnostics("error")
            log(f"失败: {e}")
            yield sse({"error": {"message": str(e), "type": "bridge_error"}})
            yield sse("[DONE]")


async def nonstream(req, prompt):
    parts = []
    rid = "chatcmpl-" + uuid.uuid4().hex
    async with lock:
        selected_model = await send(prompt, req.new_conversation, req.model)
        async for part in updates():
            parts.append(part)
    return {
        "id": rid,
        "object": "chat.completion",
        "created": int(time.time()),
        "model": selected_model,
        "choices": [{
            "index": 0,
            "message": {"role": "assistant", "content": "".join(parts)},
            "finish_reason": "stop",
        }],
    }


@asynccontextmanager
async def lifespan(app):
    global pw, ctx, page
    PROFILE.mkdir(exist_ok=True)
    pw = await async_playwright().start()
    ctx = await pw.chromium.launch_persistent_context(
        user_data_dir=str(PROFILE),
        channel=CFG.get("browser_channel", "msedge"),
        headless=bool(CFG.get("headless", False)),
        viewport={"width": 1440, "height": 1000},
    )
    page = ctx.pages[0] if ctx.pages else await ctx.new_page()
    await page.goto(URL, wait_until="domcontentloaded", timeout=120000)
    log("API 与浏览器已就绪")
    cleanup_task = asyncio.create_task(periodic_session_cleanup())
    try:
        yield
    finally:
        cleanup_task.cancel()
        try:
            await cleanup_task
        except asyncio.CancelledError:
            pass
        try:
            await ctx.close()
        except Exception:
            pass
        try:
            await pw.stop()
        except Exception:
            pass


app = FastAPI(title="Copilot Local Bridge Agent", version="8.0.5", lifespan=lifespan)


@app.get("/")
async def root():
    return {"name": "Copilot Local Bridge Agent", "version": "8.0.5", "docs": "/docs", "models": "/v1/models", "agent": "/v1/agent/completions"}


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "busy": lock.locked(),
        "page_url": page.url if page else None,
        "default_model": DEFAULT_MODEL,
    }


@app.get("/v1/models")
async def models():
    created = int(time.time())
    return {
        "object": "list",
        "data": [
            {
                "id": model_id,
                "object": "model",
                "created": created,
                "owned_by": "microsoft-copilot",
                "description": item["description"],
            }
            for model_id, item in MODELS.items()
        ],
    }


@app.get("/v1/chat/completions")
async def help_get():
    return {
        "message": "请使用 POST，或运行 python test_stream.py",
        "available_models": list(MODELS),
    }


@app.post("/v1/chat/completions")
async def chat(req: Request):
    # Validate before creating StreamingResponse, so an invalid model returns HTTP 400.
    req.model = normalize_model(req.model)
    prompts = [m.content.strip() for m in req.messages if m.role == "user" and m.content.strip()]
    if not prompts:
        raise HTTPException(400, "至少需要一条 user 消息")
    if req.stream:
        return StreamingResponse(
            stream_response(req, prompts[-1]),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )
    try:
        return await nonstream(req, prompts[-1])
    except HTTPException:
        raise
    except Exception as e:
        await diagnostics("error")
        raise HTTPException(500, str(e)) from e


class AgentSessionManager:
    def __init__(self, timeout_seconds: int = 1800, max_sessions: int = 20):
        self.timeout_seconds = max(60, int(timeout_seconds))
        self.max_sessions = max(1, int(max_sessions))
        self.sessions: dict[str, dict] = {}

    def cleanup(self):
        now = time.time()
        expired = [sid for sid, item in self.sessions.items() if now - item["last_used"] > self.timeout_seconds]
        for sid in expired:
            self.sessions.pop(sid, None)
        if len(self.sessions) > self.max_sessions:
            ordered = sorted(self.sessions.items(), key=lambda pair: pair[1]["last_used"])
            for sid, _ in ordered[:len(self.sessions) - self.max_sessions]:
                self.sessions.pop(sid, None)
        return expired

    def get(self, session_id: str):
        self.cleanup()
        item = self.sessions.get(session_id)
        if item:
            item["last_used"] = time.time()
        return item

    def save(self, session_id: str, url: str, model: str, workspace: str | None = None):
        now = time.time()
        created = self.sessions.get(session_id, {}).get("created", now)
        self.sessions[session_id] = {
            "id": session_id, "url": url, "model": model,
            "created": created, "last_used": now,
            "workspace": workspace or self.sessions.get(session_id, {}).get("workspace"),
        }
        self.cleanup()

    def delete(self, session_id: str):
        return self.sessions.pop(session_id, None) is not None

    def list(self):
        self.cleanup()
        now = time.time()
        return [{**item, "idle_seconds": int(now - item["last_used"])}
                for item in sorted(self.sessions.values(), key=lambda x: x["last_used"], reverse=True)]

async def periodic_session_cleanup():
    while True:
        await asyncio.sleep(60)
        expired = AGENT_SESSIONS.cleanup()
        if expired:
            log(f"已清理 {len(expired)} 个超时 Agent 会话")

AGENT_CFG = CFG.get("agent", {})
AGENT_WORKSPACE = (BASE / AGENT_CFG.get("workspace", "workspace")).resolve()
AGENT_TOOLS = ToolRegistry(AGENT_WORKSPACE, AGENT_CFG)
AGENT_SESSIONS = AgentSessionManager(
    AGENT_CFG.get("session_timeout_seconds", 1800),
    AGENT_CFG.get("max_sessions", 20),
)

def _has_complete_agent_action(text: str) -> bool:
    try:
        from agent import AgentRunner
        return AgentRunner._parse(text).get("type") in {"tool", "final"}
    except Exception:
        return False

async def wait_agent_answer(previous: str = "") -> str:
    deadline = time.monotonic() + TIMEOUT
    current = ""
    last_change = time.monotonic()
    seen_new = False
    while time.monotonic() < deadline:
        await asyncio.sleep(POLL)
        value = (await current_answer()).strip()
        if not value or value == previous:
            continue
        seen_new = True
        if value != current:
            current = value
            last_change = time.monotonic()
        complete = _has_complete_agent_action(current)
        stable_for = time.monotonic() - last_change
        signal = await completion_signal()
        # A complete action plus the page completion signal is enough. Otherwise
        # require a longer stable window to avoid capturing partial JSON.
        if signal and complete and stable_for >= max(0.6, POLL * 2):
            await diagnostics("agent_answer_ready")
            return current
        if signal and stable_for >= max(STABLE, 2.0):
            await diagnostics("agent_answer_stable")
            return current
    final = (await current_answer()).strip()
    if seen_new and final and final != previous:
        return final
    await diagnostics("agent_answer_timeout")
    raise TimeoutError("等待新的 Agent JSON 回答超时，请查看 last_page.txt")

async def agent_chat_once(prompt: str, model_id: str, make_new: bool = False) -> str:
    previous = "" if make_new else (await current_answer()).strip()
    await send(prompt, make_new, model_id)
    return await wait_agent_answer(previous)

async def run_agent(req: AgentRequest):
    if not AGENT_CFG.get("enabled", True):
        raise HTTPException(503, "Agent 功能已禁用")
    req.model = normalize_model(req.model)
    user_parts = [m.content.strip() for m in req.messages if m.role == "user" and m.content.strip()]
    if not user_parts:
        raise HTTPException(400, "至少需要一条 user 消息")
    task = "\n".join(f"[{m.role}] {m.content.strip()}" for m in req.messages if m.content.strip())
    session_id = req.session_id or ("web-" + uuid.uuid4().hex[:12])
    requested_workspace = req.workspace.strip() if req.workspace else None

    async with lock:
        existing = AGENT_SESSIONS.get(session_id) if req.reuse_session else None
        workspace = requested_workspace or (existing or {}).get("workspace") or str(AGENT_WORKSPACE)
        AGENT_TOOLS.set_root(workspace, create=False)
        if existing and existing.get("url"):
            try:
                if page.url != existing["url"]:
                    await page.goto(existing["url"], wait_until="domcontentloaded", timeout=120000)
                    await asyncio.sleep(1)
            except Exception:
                AGENT_SESSIONS.delete(session_id)
                existing = None

        first_turn = True
        async def session_agent_turn(prompt: str, model_id: str) -> str:
            nonlocal first_turn, existing
            make_new = first_turn and existing is None
            first_turn = False
            answer = await agent_chat_once(prompt, model_id, make_new=make_new)
            AGENT_SESSIONS.save(session_id, page.url, model_id, str(AGENT_TOOLS.root))
            existing = AGENT_SESSIONS.get(session_id)
            return answer

        runner = AgentRunner(
            AGENT_TOOLS,
            session_agent_turn,
            max_steps=req.max_steps or int(AGENT_CFG.get("max_steps", 8)),
        )
        result = await runner.run(task, req.model)
        AGENT_SESSIONS.save(session_id, page.url, req.model, str(AGENT_TOOLS.root))
        return result, session_id

async def stream_agent(req: AgentRequest):
    rid = "agent-" + uuid.uuid4().hex
    created = int(time.time())
    try:
        result, session_id = await run_agent(req)
        yield sse({
            "id": rid,
            "object": "chat.completion.chunk",
            "created": created,
            "model": req.model,
            "choices": [{"index": 0, "delta": {"role": "assistant"}, "finish_reason": None}],
            "agent_steps": result.steps,
            "session_id": session_id,
            "workspace": str(AGENT_TOOLS.root),
        })
        yield sse({
            "id": rid,
            "object": "chat.completion.chunk",
            "created": created,
            "model": req.model,
            "choices": [{"index": 0, "delta": {"content": result.content}, "finish_reason": None}],
        })
        yield sse({
            "id": rid,
            "object": "chat.completion.chunk",
            "created": created,
            "model": req.model,
            "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
        })
    except Exception as exc:
        yield sse({"error": {"message": str(exc), "type": "agent_error"}})
    yield sse("[DONE]")

@app.get("/ui", include_in_schema=False)
async def web_ui():
    return FileResponse(BASE / "webui" / "index.html")

@app.get("/v1/agent/sessions")
async def list_agent_sessions():
    return {"timeout_seconds": AGENT_SESSIONS.timeout_seconds, "sessions": AGENT_SESSIONS.list()}

@app.delete("/v1/agent/sessions/{session_id}")
async def delete_agent_session(session_id: str):
    return {"deleted": AGENT_SESSIONS.delete(session_id), "session_id": session_id}

@app.post("/v1/agent/sessions/cleanup")
async def cleanup_agent_sessions():
    return {"expired": AGENT_SESSIONS.cleanup(), "sessions": AGENT_SESSIONS.list()}

@app.get("/v1/agent/workspace")
async def get_agent_workspace():
    return {"workspace": str(AGENT_TOOLS.root)}

@app.post("/v1/agent/workspace")
async def set_agent_workspace(payload: dict):
    path = str(payload.get("path", "")).strip()
    if not path:
        raise HTTPException(400, "path 不能为空")
    try:
        return {"workspace": AGENT_TOOLS.set_root(path, bool(payload.get("create", False)))}
    except Exception as exc:
        raise HTTPException(400, str(exc)) from exc

@app.get("/v1/agent/tools")
async def agent_tools():
    return {"workspace": str(AGENT_TOOLS.root), "tools": AGENT_TOOLS.descriptions()}

@app.post("/v1/agent/completions")
async def agent_completions(req: AgentRequest):
    if req.stream:
        return StreamingResponse(
            stream_agent(req),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )
    try:
        result, session_id = await run_agent(req)
        return {
            "id": "agent-" + uuid.uuid4().hex,
            "object": "chat.completion",
            "created": int(time.time()),
            "model": req.model,
            "choices": [{
                "index": 0,
                "message": {"role": "assistant", "content": result.content},
                "finish_reason": "stop",
            }],
            "agent_steps": result.steps,
            "session_id": session_id,
            "workspace": str(AGENT_TOOLS.root),
        }
    except HTTPException:
        raise
    except Exception as exc:
        await diagnostics("agent_error")
        raise HTTPException(500, str(exc)) from exc
