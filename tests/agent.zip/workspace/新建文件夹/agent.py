from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any, Awaitable, Callable

from tools import ToolRegistry

ChatFunction = Callable[[str, str], Awaitable[str]]


@dataclass
class AgentResult:
    content: str
    steps: list[dict[str, Any]]


class AgentRunner:
    def __init__(self, tools: ToolRegistry, chat: ChatFunction, max_steps: int = 8):
        self.tools = tools
        self.chat = chat
        self.max_steps = max(1, min(int(max_steps), 30))

    def _system_prompt(self) -> str:
        return """你是一个本地任务 Agent。你可以通过工具处理工作区文件。
每次只返回一个严格 JSON 对象，不要使用 Markdown 代码块，不要输出 JSON 之外的文字。
可用格式只有：
1. 调用工具：{"type":"tool","tool":"工具名","arguments":{...},"reason":"简短原因"}
2. 完成任务：{"type":"final","content":"最终答复"}
规则：
- 先检查再修改，避免覆盖重要文件。
- 所有路径都是工作区相对路径。
- 工具失败后应根据错误调整，不要重复同一失败动作。
- 完成时说明实际做了什么以及输出文件路径。
可用工具：
""" + json.dumps(self.tools.descriptions(), ensure_ascii=False)

    @staticmethod
    def _parse(text: str) -> dict[str, Any]:
        # Copilot UI may temporarily prepend text such as "Sorting it out...".
        # Scan every opening brace and accept the first complete Agent object.
        cleaned = text.strip()
        cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", cleaned, flags=re.I | re.S).strip()
        decoder = json.JSONDecoder()
        candidates = [0] if cleaned.startswith("{") else []
        candidates.extend(i for i, char in enumerate(cleaned) if char == "{" and i not in candidates)
        for start in candidates:
            try:
                obj, _ = decoder.raw_decode(cleaned[start:])
            except json.JSONDecodeError:
                continue
            if isinstance(obj, dict) and obj.get("type") in {"tool", "final"}:
                return obj
        raise ValueError("Copilot 未返回完整、可解析的 Agent JSON 动作")

    async def run(self, user_request: str, model: str) -> AgentResult:
        history: list[dict[str, Any]] = []
        steps: list[dict[str, Any]] = []
        for index in range(1, self.max_steps + 1):
            prompt = self._system_prompt() + "\n\n用户任务：\n" + user_request
            if history:
                prompt += "\n\n已执行记录：\n" + json.dumps(history, ensure_ascii=False)
            prompt += f"\n\n当前是第 {index}/{self.max_steps} 步。请返回下一个 JSON 动作。"
            raw = await self.chat(prompt, model)
            try:
                action = self._parse(raw)
            except Exception as exc:
                history.append({"step": index, "invalid_response": raw[-4000:], "error": str(exc)})
                steps.append({"step": index, "status": "invalid_action", "error": str(exc)})
                continue
            if action["type"] == "final":
                return AgentResult(str(action.get("content", "")), steps)
            tool = str(action.get("tool", ""))
            arguments = action.get("arguments") or {}
            step = {"step": index, "tool": tool, "arguments": arguments, "reason": action.get("reason", "")}
            try:
                result = await self.tools.execute(tool, arguments)
                step.update({"status": "ok", "result": result})
                history.append(step)
            except Exception as exc:
                step.update({"status": "error", "error": str(exc)})
                history.append(step)
            steps.append(step)
        return AgentResult(f"Agent 已达到最大步骤数 {self.max_steps}，任务未正常结束。", steps)
