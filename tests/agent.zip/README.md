# Copilot Local Bridge Agent 8.0.2

这是基于原 `app.py` 增加的纯 Python 轻量 Agent。所有入口和业务代码均为 Python，不包含 CMD、BAT、PowerShell 或 Node.js 项目文件。

## 安装与启动

```text
python install.py
python login.py
python start.py
```

浏览器登录只需执行一次。服务地址：`http://127.0.0.1:8765`，接口文档：`http://127.0.0.1:8765/docs`。

## 测试

普通流式聊天：

```text
python test_stream.py
```

Agent 文件任务：

```text
python test_agent.py
```

## 接口

- `POST /v1/chat/completions`：原 OpenAI 风格聊天接口
- `POST /v1/agent/completions`：Agent 接口
- `GET /v1/models`：模型列表
- `GET /v1/agent/tools`：工具列表
- `GET /health`：状态

Agent 请求示例：

```json
{
  "model": "copilot-auto",
  "messages": [{"role": "user", "content": "读取 logs/app.log，分析错误并写入 summary.txt"}],
  "stream": false,
  "max_steps": 8
}
```

## 安全设置

Agent 默认只能访问包内 `workspace` 目录。

- `allow_delete: false`：禁止删除
- `allow_python: false`：禁止执行 Copilot 生成的 Python
- 路径越界保护：拒绝 `workspace` 外路径
- `max_steps`：避免无限循环
- `run_python` 即使启用也不是安全沙箱，只应在可信环境使用

如需让 Agent 处理现有文件，请将文件放进 `workspace`。


## Copilot 会话策略

每次 Agent API 请求只新建一个 Copilot 会话。Agent 后续工具步骤会继续使用同一个会话，不会再按步骤创建多个聊天记录。新的 Agent API 请求仍会创建新的会话，从而避免不同任务之间互相污染上下文。
