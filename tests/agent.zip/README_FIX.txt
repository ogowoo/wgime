Copilot Local Bridge Agent v8.0.7 patch

根因：长 append_text JSON 在生成中途会短暂停顿。旧版把“文本稳定”或已有 Sources 当成完成，因此提前读取到被截断的 JSON。截图中的停止按钮仍然可见，证明回答当时尚未完成。

修复：
- 只有同时满足以下条件才接收动作：JSON 可完整解析、Copilot 停止按钮消失、内容保持不变至少 1.5 秒。
- 删除“仅稳定但不可解析也返回”的分支。
- 单次长文件片段建议降到 1800 字符，降低网页输出截断概率。
- 默认解析修复次数提高到 3。
- max_steps 上限统一为 100。
- 保留 set_root 兼容修复。

更新：停止 start.py，覆盖 app.py、agent.py、tools.py，重新运行 python start.py，然后 Ctrl+F5。
